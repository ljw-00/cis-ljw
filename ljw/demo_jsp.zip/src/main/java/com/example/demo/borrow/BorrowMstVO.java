package com.example.demo.borrow;

import java.util.List;

import lombok.Data;

@Data
public class BorrowMstVO {
    private List<BorrowTblVO> borrowList;
}
