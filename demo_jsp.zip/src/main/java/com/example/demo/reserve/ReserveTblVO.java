package com.example.demo.reserve;

import lombok.Data;

@Data
public class ReserveTblVO {
    
    private String brCode;
    private String seq;
    private String userId;
    private String isbn;
    private String rsDate;
}
