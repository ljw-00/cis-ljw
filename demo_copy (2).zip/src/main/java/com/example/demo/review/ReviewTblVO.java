package com.example.demo.review;

import lombok.Data;

@Data
public class ReviewTblVO {

    private String regDate;
    private String userId;
    private String review;
    private String isbn;
}